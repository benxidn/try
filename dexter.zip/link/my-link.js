function Home() {
   window.open("../../index.html","_self");
   }
function Channel() {
   window.open("https://benxidn.github.io/link/subscribe.html","_self");
   }
function Unduh() {
   window.open("https://youtu.be/zQ4KXfQKTho?si=kiW5zMFRySbivJBR","_self");
   }
function Drone() {
   window.open("https://benxidn.github.io/link/subscribe.html","_self");
   }
function Fakecez() {
   window.open("https://benxidn.github.io/link/subscribe.html","_self");
   }
function Dexter() {
   window.open("https://benxidn.github.io/link/subscribe.html","_self");
   }
