# Dexter Modz
<html>
<body>
  <h1>Maintenance</h1>
  <p style="text-align:justify">Situs sedang dalam perbaikan. Silahkan kembali lagi nanti, atau silahkan bergabung ke grup Telegram berikut untuk mendapatkan informasi lainnya.</p>
  <input type="button" value="Join Telegram" onclick="this.value='Loading . . .';location.href='https://t.me/dextermodzz'" />
</body>
</html>
